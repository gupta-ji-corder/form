        // about us js
const aboutSection = document.createElement('section');
aboutSection.id = 'about';
aboutSection.classList.add('about');
document.body.insertBefore(aboutSection, document.body.firstChild);

        // footer js
const footer = document.createElement('footer');
footer.classList.add('footer');
document.body.appendChild(footer);

